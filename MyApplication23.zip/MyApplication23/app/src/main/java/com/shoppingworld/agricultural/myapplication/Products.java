package com.shoppingworld.agricultural.myapplication;

/**
 * Created by Belal on 10/18/2017.
 */


public class Products {
    private String id;
    private String title;
    private String shortdesc;
    private String approval;
    //private double price;
    private String image;
    private String deliveryupd;
    private boolean isSelected;
    public Products(String id,String title,String shortdesc,String approval,String deliveryupd) {
        this.id = id;
        this.title = title;
        this.shortdesc = shortdesc;
        this.approval = approval;
        this.deliveryupd=deliveryupd;
        //this.price = price;
        //this.image = image;
    }

    public Products() {

    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }
    public String getDeliveryupd() {
        return deliveryupd;
    }
    public String getQuantity() {
        return shortdesc;
    }

    public String getApproval() {
        return approval;
    }
/*
    public double getPrice() {
        return price;
    }*/

    public String getImage() {
        return image;
    }

    public void setTitle(String animal) {
        this.title = animal;
    }
    public boolean getSelected() {
        return isSelected;
    }


    public void setSelected(boolean selected) {
        this.isSelected = selected;
    }

    public void setTitle() {
    }


}
