package com.shoppingworld.agricultural.myapplication;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class hello extends AppCompatActivity {
    List<String> list = new ArrayList<>();
    List<String> alist = new ArrayList<>();
    List<String> qlist = new ArrayList<>();
    List<String> qqlist = new ArrayList<>();
String[] c;
    String ssf="";

    AlertDialog.Builder builder;
int as=0;
    String t;
    TextView t1, t2, t3,t4;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello);
        t1 = (TextView) findViewById(R.id.textView2);
        t2 = (TextView) findViewById(R.id.textView3);
        t3 = (TextView) findViewById(R.id.textView4);
        t4=(TextView)findViewById(R.id.textView7);

        for (int i = 0; i < ProductssAdapter.productList.size(); i++) {
            if (ProductssAdapter.productList.get(i).getSelected()) {
                list.add(ProductssAdapter.productList.get(i).getTitle());
                alist.add(ProductssAdapter.productList.get(i).getApproval());
                qlist.add(ProductssAdapter.productList.get(i).getQuantity());
                qqlist.add(ProductssAdapter.productList.get(i).getId());

                //   tv.setText(tv.getText() + " " +list);
            }
        }

        String s = list.toString();
        final String ss = alist.toString();
        String sss = qlist.toString();
         ssf=qqlist.toString();
        as=ssf.length();
        ssf=ssf.substring(0,as);
        as=as-1;
        ssf=ssf.substring(1,as);
        String ui=Integer.toString(as);
//ssf.charAt(ssf.length()-1);
//c= (String[]) qlist.toArray();


        list.clear();
        alist.clear();
        qlist.clear();
        t1.setText(s);
        t2.setText(ss);
        t3.setText(sss);
        t4.setText(ssf);
        if (ss.equals("[Orderapproved]")) {
            Toast.makeText(getApplicationContext(),"ADA"+ ui, Toast.LENGTH_LONG).show();
        }
        b1 = (Button) findViewById(R.id.but);
        final String server_url="http://192.168.43.177/new11.php?userid="+ssf;
        //b1.setEnabled(false);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringRequest stringRequest = new StringRequest(Request.Method.GET, server_url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                       /* builder.setTitle("Server Response");
                        builder.setMessage("Response :"+response);
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                t4.setText("");
                               t3.setText("");
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();*/

                    }
                }

                        , new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(hello.this,"some error found .....",Toast.LENGTH_SHORT).show();
                        error.printStackTrace();

                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map <String,String> Params = new HashMap<String, String>();
                        Params.put("id",ssf);
                       Params.put("feedback",ss);
                        return Params;

                    }
                };
                Mysingleton.getInstance(hello.this).addTorequestque(stringRequest);
            }
        });





    }
}
