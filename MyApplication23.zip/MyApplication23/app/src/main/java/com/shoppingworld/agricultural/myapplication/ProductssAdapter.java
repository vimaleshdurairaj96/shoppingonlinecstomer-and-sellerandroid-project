package com.shoppingworld.agricultural.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Belal on 10/18/2017.
 */

public class ProductssAdapter extends RecyclerView.Adapter<ProductssAdapter.ProductViewHolder> {
public interface OnItemClickListener{
    void onItemClick(Products products);
    }

    private Context mCtx;
    //private final PublishSubject<String> onClickSubject = PublishSubject.create();
    public static ArrayList<Products> imageModelArrayList;
    public static List<Products> productList;
public String sd;
    public ProductssAdapter(Context mCtx, List<Products> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }


    /*public ProductssAdapter(MainActivity productList, List<Products> listener) {
        this.productList=productList;

    }*/

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.layout3, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        Products product = productList.get(position);
        String s = product.getTitle();
        Toast.makeText(mCtx, s, Toast.LENGTH_LONG).show();
        Toast.makeText(mCtx, s, Toast.LENGTH_LONG).show();
        //loading the image
      /*  Glide.with(mCtx)
                .load(product.getImage())
                .into(holder.imageVi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ew);
*/
        String sd = product.getTitle();
        if (!(sd.equals(null) || sd.equals(""))) {
            holder.textViewTitle.setText(product.getTitle());
            holder.textViewShortDesc.setText(product.getQuantity());
            holder.textViewRating.setText(product.getApproval());
            holder.textViewTitle.setTag(position);
            holder.TextViewid.setText(product.getId());
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Integer s = (Integer) holder.textViewTitle.getTag();
                    if (productList.get(s).getSelected()) {
                        productList.get(s).setSelected(false);
                    } else {
                        productList.get(s).setSelected(true);
                    }
                    Intent a = new Intent(mCtx, hello.class);
                    mCtx.startActivity(a);
                    //holder.itemView.get(position);
                    //sd=(String)v.getContext().getText();
                /*Intent a=new Intent(mCtx,hello.class);

                mCtx.startActivity(a);*/
                    //a.putExtra()
                }
            });
            //  holder.itemView.
//        holder.textViewRating.setText(product.getRating());
            //holder.s1.setOnItemClickListener();
            //String s=product.getTitle();
//Toast.makeText(mCtx,s,Toast.LENGTH_LONG).show();

        }
    }


    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewShortDesc, textViewRating, textViewPrice,TextViewid;
        ImageView imageView;
        public Spinner s1;
        CheckBox checkbox;

        public ProductViewHolder(View itemView) {
            super(itemView);
            TextViewid = itemView.findViewById(R.id.textView6);
            textViewTitle = itemView.findViewById(R.id.textView11);
            textViewShortDesc = itemView.findViewById(R.id.textView12);
textViewRating=itemView.findViewById(R.id.textView15);
//textViewRating=itemView.findViewById(R.id.textView17);
            //imageView = itemView.findViewById(R.id.imageView);

        }

        }
    }
